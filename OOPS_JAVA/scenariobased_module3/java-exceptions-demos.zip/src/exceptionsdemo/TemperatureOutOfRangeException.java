package exceptionsdemo;
public class TemperatureOutOfRangeException extends Exception {
    public TemperatureOutOfRangeException(String msg) { super(msg); }
}
