package exceptionsdemo;
public class MinimumRechargeException extends Exception {
    public MinimumRechargeException(String msg) { super(msg); }
}
