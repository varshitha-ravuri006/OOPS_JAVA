package exceptionsdemo;
public class LateSubmissionException extends Exception {
    public LateSubmissionException(String msg) { super(msg); }
}
