package exceptionsdemo;
public class SeatsNotAvailableException extends Exception {
    public SeatsNotAvailableException(String msg) { super(msg); }
}
