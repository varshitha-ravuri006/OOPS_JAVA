package exceptionsdemo;
public class OverSpeedException extends Exception {
    public OverSpeedException(String msg) { super(msg); }
}
