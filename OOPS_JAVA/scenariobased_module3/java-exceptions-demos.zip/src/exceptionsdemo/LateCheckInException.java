package exceptionsdemo;
public class LateCheckInException extends Exception {
    public LateCheckInException(String msg) { super(msg); }
}
