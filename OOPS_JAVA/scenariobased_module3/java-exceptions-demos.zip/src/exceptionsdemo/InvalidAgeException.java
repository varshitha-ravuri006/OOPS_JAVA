package exceptionsdemo;
public class InvalidAgeException extends Exception {
    public InvalidAgeException(String msg) { super(msg); }
}
