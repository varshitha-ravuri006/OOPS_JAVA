package exceptionsdemo;
public class ExcessStayDurationException extends Exception {
    public ExcessStayDurationException(String msg) { super(msg); }
}
