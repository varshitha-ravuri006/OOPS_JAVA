package exceptionsdemo;
public class LowCreditScoreException extends Exception {
    public LowCreditScoreException(String msg) { super(msg); }
}
