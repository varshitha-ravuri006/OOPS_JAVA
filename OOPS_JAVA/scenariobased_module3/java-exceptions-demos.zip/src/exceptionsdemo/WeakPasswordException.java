package exceptionsdemo;
public class WeakPasswordException extends Exception {
    public WeakPasswordException(String msg) { super(msg); }
}
