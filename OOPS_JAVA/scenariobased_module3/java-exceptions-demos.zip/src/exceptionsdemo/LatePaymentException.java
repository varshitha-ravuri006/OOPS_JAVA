package exceptionsdemo;
public class LatePaymentException extends Exception {
    public LatePaymentException(String msg) { super(msg); }
}
