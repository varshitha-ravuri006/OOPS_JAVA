package exceptionsdemo;
public class InvalidPriceException extends Exception {
    public InvalidPriceException(String msg) { super(msg); }
}
