package exceptionsdemo;
public class InvalidMarksException extends Exception {
    public InvalidMarksException(String msg) { super(msg); }
}
