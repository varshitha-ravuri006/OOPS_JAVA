package exceptionsdemo;
public class EmptyCartException extends Exception {
    public EmptyCartException(String msg) { super(msg); }
}
